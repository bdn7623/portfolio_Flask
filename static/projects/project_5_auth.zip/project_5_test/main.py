from flask import Flask, render_template, redirect, url_for
from models import db
from models import Article, Author, Category
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_admin.form.upload import ImageUploadField
from auth_part import auth_module,login_manager,User
from flask_login import current_user

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project_51.db"
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
app.secret_key = "secret_key"

db.init_app(app)
with app.app_context():
    db.create_all()

app.register_blueprint(auth_module)
login_manager.init_app(app)

class ImageView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('/login'))

    form_extra_fields = {
        'img': ImageUploadField(base_path='static')
    }

@app.route("/")
def get_categories():
    categories = Category.query.all()
    return render_template('categories.html', categories=categories)

@app.route("/categories/<int:category_id>")
def get_category(category_id):
    category = Category.query.filter(Category.id==category_id).first()
    return render_template('category.html', category=category)

@app.route("/articles/<int:article_id>")
def get_article(article_id):
    article = Article.query.filter(Article.id==article_id).first()
    return render_template('article.html', article=article)

admin = Admin(app, name='Project_5', template_mode='bootstrap3')

admin.add_view(ImageView(Article, db.session))
admin.add_view(ImageView(Author, db.session))
admin.add_view(ImageView(Category, db.session))
admin.add_view(ImageView(User, db.session))

app.run()
